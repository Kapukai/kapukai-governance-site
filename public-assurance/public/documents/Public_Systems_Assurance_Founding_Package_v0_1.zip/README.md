# Public Systems Assurance package v0.1

Start with the editable Word master. The source folder contains the adoption guide and all six documents separately as Markdown. The master has 21 pages. Forms can be edited in Word or printed; they are not an online intake system.

Status: independent discussion proposal, not enacted law, not an official agency form, and not ISO or NIST certification. Model legislation requires legislative-counsel review. No documents have been submitted or published to recipients.

Included: founding charter; federal model enabling legislation; 19-control technical audit standard; public systems-audit request; protected individual-review request; correction and closure record; historical and presidential adoption examples; 90-day adoption plan; primary sources.

SHA256SUMS.json identifies this release's file bytes. It detects alteration; it does not certify truth or legal validity. Preserve old releases and publish a change log when revising. Source page separators indicate the master document's page breaks.
