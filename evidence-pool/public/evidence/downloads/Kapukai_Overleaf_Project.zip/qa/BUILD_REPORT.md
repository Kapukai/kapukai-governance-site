# Build and review report

Review date: 2026-10-01. Automated and AI-assisted checks; no human approval or legal certification is represented.

- Three documents compiled with pdfLaTeX and latexmk: dossier 46 pages, atlas 15 pages, toolkit 20 pages.
- No undefined citations or overfull boxes in the final logs. Atlas has ordinary underfull-line warnings. A duplicate title-page anchor warning does not affect printed content; source links and references resolve.
- Page contact sheets were inspected for the three documents. Individual covers, case/method pages and atlas diagrams were inspected at readable resolution. A diagram label overlap was corrected and rerendered.
- All 71 source identifiers are unique; case source references resolve. Source records include URL, date, pinpoint, type, scope and limitations. Source records are not necessarily independent sources.
- Six public source PDFs were acquired and their recorded SHA-256 values checked. The archive contains downloaded copies, not certified originals.
- Evidence manager: all 11 integration tests passed, including preservation of input bytes, corruption/custody detection, symlink and path-traversal rejection, CSV formula protection, public-only metadata export and actual LaTeX compilation with hostile input.
- Separate editorial review corrected Woolsey's case citations to avoid implying he participated in AHI research, and clarified that the Thomas source was reviewed as indexed text.

## Limits

The research is bounded, not exhaustive. Some original clinical, forensic and court files were not acquired. Some source pages were accessible only in search-index text. Those limits appear in the source register. No independent statistical cluster analysis was performed. Records requests are templates and have not been sent.

The website has a separate verification report. Local compilation does not establish that any production website or Overleaf account has been accessed or deployed.
