from pathlib import Path
import json,csv
B=Path(__file__).resolve().parent;O=B.parent if B.name=='scripts' else B/'dossier_project'
def esc(s):return str(s).replace('&',r'\&').replace('_',r'\_').replace('%',r'\%')
start=r'''\input{preamble.tex}
\begin{document}
\cover{Connections\newline with evidence}{Research atlas}{Maps of documented relationships, attributed reports, records and review pathways. Every edge says what it means. No map here establishes one coordinated targeting network.}
\tableofcontents\clearpage
\section{Read the edges before the pattern}
\begin{note}An employment link, a report about a professional relationship, and evidence of operational direction are different edges. Co-location, similar symptoms and recurring words in headlines are not perpetrator links.\end{note}
\begin{tabularx}{\linewidth}{p{0.24\linewidth}X}
\toprule Solid relationship & Documented for the narrow label shown.\\
Dashed relationship & Attributed report or a proposed evidentiary step; see each plate's legend.\\
No edge & No supported relationship asserted. Absence from a diagram does not prove nonexistence.\\
Arrow & Direction of a process, document, payment or instruction only as labeled.\\\bottomrule
\end{tabularx}

The atlas uses the dossier's source IDs and research cutoff of October 1, 2026. These are relationship schematics, not geospatial intelligence or a statistical network analysis. The underlying evidence is uneven: official documents, mirrors and news accounts have different provenance limits. Consult the full dossier before reusing any assertion.

\subsection{The edge register}
The editable \texttt{data/connections.csv} states endpoints, relationship type, status, source and causal limitation. New edges require a record, a date, a pinpoint and an explanation of what the record establishes. A claim of coordination needs evidence of coordination, such as attributable instructions or transactions; it cannot be inferred from a dense-looking graph.
'''
styles=r'''\begin{center}\begin{tikzpicture}[
 box/.style={draw=navy,fill=pale,rounded corners=2pt,text width=4.8cm,minimum height=1.1cm,align=center,font=\small,inner sep=7pt},
 smallbox/.style={box,text width=3.3cm},
 link/.style={draw=navy,line width=0.85pt,-{Latex[length=2mm]}},
 rel/.style={draw=teal,line width=0.85pt},
 noteedge/.style={font=\scriptsize,fill=white,align=center,inner sep=3pt},
 hypothesis/.style={draw=gold,dashed,line width=1pt,-{Latex[length=2mm]}}]
'''
end=r'\end{tikzpicture}\end{center}'
pages=[]
def plate(title,intro,diagram,caption):
    pages.append(r'\clearpage\section{'+title+'}\n'+intro+'\n'+styles+diagram+end+'\n'+r'\begin{note}'+caption+r'\end{note}'+'\n')
plate('Source, assertion, finding',
      r'One source can establish that an allegation was made without establishing the allegation itself. The April 2026 House letter is a useful example.\cite{R01}',r'''
\node[box] (media) at (0,0) {Press reports};
\node[box] (letter) at (7,0) {House inquiry letter\\20 April 2026};
\node[box] (inquiry) at (7,-3) {Verified proposition\\An inquiry requested information};
\node[box] (allegation) at (0,-3) {Underlying allegation\\Cases may be connected};
\node[box] (records) at (0,-6) {Needed evidence\\Actor-specific records and forensics};
\node[box] (finding) at (7,-6) {A case finding\\Requires independent evaluation};
\draw[link] (media)--node[noteedge,above]{cited in letter}(letter);
\draw[link] (letter)--node[noteedge,right]{directly supports}(inquiry);
\draw[hypothesis] (media)--node[noteedge,left]{reported claim}(allegation);
\draw[hypothesis] (allegation)--node[noteedge,left]{must be tested}(records);
\draw[hypothesis] (records)--node[noteedge,above]{may support or refute}(finding);
''','Solid arrows show document provenance. Dashed arrows show an unproven proposition and the work required to evaluate it. An inquiry cannot be used to close the evidentiary gap it was opened to investigate.')
plate('Olson: documented action and later review',
      r'The historical record documents an exposure and institutional response. The manner of the fatal fall remains a separate contested proposition.\cite{H01,H02,H03,H04}',r'''
\node[smallbox] (army) at (0,0) {U.S. Army\\Olson employment};
\node[smallbox] (olson) at (5,0) {Frank Olson};
\node[smallbox] (cia) at (10,0) {CIA personnel};
\node[box] (death) at (5,-2.7) {Fatal hotel fall\\November 1953};
\node[smallbox] (ford) at (0,-5.7) {Ford White House\\1975 apology};
\node[smallbox] (law) at (5,-5.7) {1976 relief law};
\node[smallbox] (court) at (10,-5.7) {2013 civil dismissal};
\draw[rel] (army)--node[noteedge,above]{employment / H03}(olson);
\draw[link] (cia)--node[noteedge,above]{LSD exposure / H01}(olson);
\draw[link] (olson)--node[noteedge,right]{later event}(death);
\draw[link] (death)--node[noteedge,left]{subsequent response}(ford);
\draw[link] (death)--node[noteedge,right]{subsequent response}(law);
\draw[link] (death)--node[noteedge,right]{later litigation}(court);
''','Sequence does not alone establish a mechanism of death. The court opinion recounts a family allegation about later forensic findings; dismissal did not decide that the death was a homicide. The dossier retains conflicting historical date/floor descriptions.')
plate('Recent cases: affiliations are context',
      r'Employment and professional reporting define context; they do not make an incident a classified-work attack. Solid lines below are employer or society records; dashed lines are attributed reporting.\cite{R05,R07,R08,R18,R01,R20}',r'''
\node[box] (jpl) at (0,0) {NASA Jet Propulsion Laboratory};
\node[box] (hicks) at (7,0) {Michael Hicks / R07\\Frank Maiwald / R18 (obituary)};
\node[box] (reza) at (7,-2.1) {Monica Reza / R01\\House letter cites press reports};
\node[box] (lanl) at (0,-4.2) {Los Alamos employment reporting};
\node[box] (nm) at (7,-4.2) {Casias and Chavez / R20\\Roles differ; no common clearance proved};
\node[box] (usaf) at (0,-6.3) {Air Force Research Laboratory};
\node[box] (mc) at (7,-6.3) {McCasland / R05\\Historical command role};
\node[box] (cal) at (0,-8.4) {Caltech / IPAC};
\node[box] (cg) at (7,-8.4) {Carl Grillmair / R08};
\draw[rel] (jpl)--node[noteedge,above]{past employment}(hicks);
\draw[hypothesis] (jpl)--node[noteedge,above,sloped]{reported affiliation}(reza);
\draw[hypothesis] (lanl)--node[noteedge,above]{reported roles}(nm);
\draw[rel] (usaf)--node[noteedge,above]{official biography}(mc);
\draw[rel] (cal)--node[noteedge,above]{employer memorial}(cg);
''','No lines connect the incidents to each other. Maiwald is supported by an obituary rather than an employer record; its limits remain in the dossier. Casias is deceased in later records. Never infer current missing status from an affiliation map.')
plate('Specific foreign-domestic links: comparators',
      r'These established examples show the specificity needed for attribution. They are separate operations and are not asserted to connect the deaths.\cite{P01,P02,P03,P04}',r'''
\node[smallbox] (kgb) at (5,0) {KGB / Soviet-Russian\\intelligence contacts};
\node[smallbox] (ames) at (0,-2.7) {Aldrich Ames};
\node[smallbox] (hanssen) at (10,-2.7) {Robert Hanssen};
\node[smallbox] (cia) at (0,-5) {CIA insider access};
\node[smallbox] (fbi) at (10,-5) {FBI insider access};
\draw[link] (ames)--node[noteedge,above,sloped]{transfer / P01}(kgb);
\draw[link] (hanssen)--node[noteedge,above,sloped]{transfer / P02--P03}(kgb);
\draw[link] (cia)--node[noteedge,left]{access}(ames);
\draw[link] (fbi)--node[noteedge,right]{access}(hanssen);
\node[smallbox] (mps) at (0,-7.5) {PRC Ministry\\of Public Security};
\node[smallbox] (lu) at (5,-7.5) {Lu Jianwang};
\node[smallbox] (ny) at (10,-7.5) {New York office};
\draw[link] (mps)--node[noteedge,above]{direction / P04}(lu);
\draw[link] (lu)--node[noteedge,above]{operation / P04}(ny);
''','Each actor-to-operation link has specific evidence and a guilty plea or reported jury verdict. Nationality, ordinary international contact, institutional membership or shared scientific interests are not substitutes for that evidence.')
plate('Control points and a correction loop',
      r'Author-created defensive architecture informed by the control register. Boxes are review domains, not identified compromised systems.\cite{C01,C02,C03,C12,C14,C15,C20}',r'''
\node[smallbox] (digital) at (0,0) {Identity, devices,\\cloud and telecom};
\node[smallbox] (physical) at (5,0) {Facilities, laboratory\\and exposure records};
\node[smallbox] (institution) at (10,0) {Personnel, procurement,\\authority and oversight};
\node[box] (capture) at (5,-2.8) {Preserved records\\Provenance, time, custody and integrity};
\node[box] (review) at (5,-5.1) {Independent review\\Support, contradiction and alternatives};
\node[smallbox] (decision) at (1,-7.6) {Decision\\Scope and responsible reviewer};
\node[smallbox] (correction) at (9,-7.6) {Correction\\Version and downstream recipients};
\draw[link] (digital)--(capture);
\draw[link] (physical)--(capture);
\draw[link] (institution)--(capture);
\draw[link] (capture)--node[noteedge,right]{lawful, scoped access}(review);
\draw[link] (review)--(decision);
\draw[link] (decision)--node[noteedge,above]{new evidence or error}(correction);
\draw[link] (correction.east) -- ++(1.0,0) |- (review.east);
''','Keep the source record, the interpretation and the decision distinct. An adverse output should remain traceable to its inputs, authority and reviewer. Correction should reach every recorded downstream use. This is a proposed architecture, not a statement that these safeguards already exist.')

geo=r'''\clearpage\section{Jurisdiction atlas: where the records live}
This is a records-location index, not a map of perpetrator movement. Specific access rights and custodians must be verified before submitting a request.\cite{C16,C17}
\begin{longtable}{p{0.22\linewidth}p{0.25\linewidth}p{0.45\linewidth}}
\toprule\textbf{Geography / subject} & \textbf{Case or context} & \textbf{Record lead and limitation}\\\midrule\endhead
New York / federal archives & Olson & Scene/death records; Ford Library; Senate hearing; civil docket. Separate original findings from later allegations. [H01--H05]\\
Maryland & Colby & Medical examiner and recovery records. This packet's autopsy is a third-party scan. [H06]\\
New Mexico & McCasland, Casias, Chavez, Garcia & Sheriff/state/local police and medical examiner records; dated missing notices can be stale. [R06, R11--R16]\\
California & Reza, Grillmair; JPL affiliations & Missing-person agency; prosecutor/court; employer records. Geography is not an operational link. [R07--R10, R18]\\
Massachusetts & Loureiro, Thomas & FBI and local investigative records; medical examiner; employer. [R03, R04, R17]\\
Virginia & Sullivan & Original medical-examiner determination and congressional scheduling documents needed. [R19]\\
Washington / federal & Woolsey; AHI assessments & Individual medical record access differs from public intelligence-assessment access. [W01--W07]\\
Moscow, Russia & Maganov & Autopsy, scene and final disposition not acquired. [W08]\\
Rayagada, India & Antov & Police and certified forensic records; later reporting describes accidental classification. [W10, W11]\\
Spain & Protosenya & Police, forensic and judicial records; staging allegation not established. [W09]\\\bottomrule
\end{longtable}

\clearpage\section{A causal claim needs separate bridges}
\begin{longtable}{p{0.19\linewidth}p{0.36\linewidth}p{0.36\linewidth}}
\toprule\textbf{Bridge} & \textbf{Potential evidence} & \textbf{What is insufficient alone}\\\midrule
Event to exposure & Contemporaneous measurement; authenticated access records; independently reviewed samples & Symptoms, rumors, missing logs or device capability in the abstract.\\
Exposure to injury & Clinical timeline; qualified mechanism assessment; controls; alternative causes & Temporal sequence without dose, timing, mechanism or clinical assessment.\\
Actor to action & Attributable instructions, financial records, access logs, communications, forensic match & Motive, institutional position, nationality or being nearby.\\
Action to coordination & Independent links between identified people, transactions, assets and event dates & Shared employer; same vendor; a list selected after events occurred.\\
Finding to new case & New case's own records and legally relevant comparison & A historical abuse used as proof of a present allegation.\\\bottomrule
\end{longtable}
This plate is an analytic framework, not an adjudication or a diagnostic rule. The evidence manager and templates preserve uncertainty so that a reviewer can challenge each bridge.

\subsection{Biological and technological hypotheses}
Separate a general capability from demonstrated exposure, clinical effect and responsible actor. Lab safety failures, chemical exposure, medical coding error and malicious conduct require different tests. Use qualified clinicians, industrial hygienists, biosafety professionals and forensic examiners where appropriate. Do not infer an agent from a nonspecific symptom pattern or perform hazardous self-testing.\cite{C09,C13,C15,W07}

\subsection{A status update is itself a map change}
When a source is corrected, recalled or superseded, update the case card, timeline, edge register, public narrative and downloadable release. The AHI recall and Casias identification illustrate why every public card needs a dated source and a revision path.\cite{W04,R11}
'''
refs=['H01','H02','H03','H04','H05','H06','R01','R03','R04','R05','R06','R07','R08','R09','R10','R11','R12','R13','R14','R15','R16','R17','R18','R19','R20','P01','P02','P03','P04','W01','W02','W03','W04','W05','W06','W07','W08','W09','W10','W11','C01','C02','C03','C09','C12','C13','C14','C15','C16','C17','C20']
data=json.load(open(O/'data/research.json'))
reftex='\\sourcesstart\n'
for s in data['sources']:
    if s['id'] in refs:reftex+='\\bibitem['+s['id']+']{'+s['id']+'} '+esc(s['author'])+'. \\textit{'+esc(s['title']).replace('’',"'").replace('–','--')+'}. '+esc(s['date']).replace('–','--')+'.\\\\\n\\url{'+s['url']+'}\\\\\n'+esc(s['locator']).replace('–','--')+'. Full provenance and limits: dossier source register.\n'
reftex+='\\sourcesend\n'
(O/'atlas.tex').write_text(start+''.join(pages)+geo+reftex+r'\end{document}')
edges=[]
def edge(a,b,rel,status,src,limit):edges.append({'edge_id':f'EDGE-{len(edges)+1:03}','from':a,'to':b,'relationship':rel,'status':status,'source_ids':src,'causal_limit':limit})
edge('Olson','Army','Employment','Documented','H03','Does not establish manner of death')
edge('CIA personnel','Olson','Nonconsensual exposure','Documented','H01','Fatal mechanism separate')
edge('Ford White House','Olson family','Apology','Documented','H02','Not a homicide verdict')
edge('Colby','Church Committee','Testimony','Documented','H07','No death-causation edge')
edge('Maryland OCME','Colby','Accidental-death opinion','Primary scan','H06','Custodian authentication needed')
edge('Hicks','JPL','Past employment','Professional society record','R07','No incident coordination proved')
edge('Maiwald','JPL','Instrument work','Obituary','R18','Source inconsistencies disclosed')
edge('Reza','JPL','Reported affiliation','Reported','R01','Derivative press claim')
edge('Reza','McCasland','Alleged professional relationship','Unverified in original records','R01','Do not draw as proven operational edge')
edge('McCasland','AFRL','Historical command','Official biography','R05','No current project or clearance inferred')
edge('Grillmair','Caltech/IPAC','Employment','Employer memorial','R08','No work-related motive proved')
edge('Loureiro','MIT','Employment','Employer memorial','R04','Not a network link')
edge('Ames','KGB','Espionage transfers','Guilty plea history','P01','Separate comparator')
edge('Hanssen','Soviet/Russian intelligence','Espionage transfers','Guilty plea and OIG findings','P02;P03','Separate comparator')
edge('MPS','Lu Jianwang','Direction/control','DOJ report of jury verdict','P04','Separate comparator; docket follow-up needed')
edge('ODNI','2023 and 2025 AHI assessments','Recall','Official memorandum','W04','No individual cause or perpetrator established')
with (O/'data/connections.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=edges[0]);w.writeheader();w.writerows(edges)
print('atlas plates',len(pages),'edges',len(edges))
