#!/usr/bin/env python3
"""Check byte identity of the public source archive; does not authenticate contents."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent.parent
manifest=root/'evidence/provenance.json'
if not manifest.exists():
    print('No source archive included in this edition. Use the full research-system ZIP.')
    sys.exit(0)
failed=[]
for rec in json.loads(manifest.read_text()):
    if rec['status']!='downloaded':continue
    p=(root/rec['path']).resolve()
    if not p.is_relative_to((root/'evidence/originals').resolve()) or not p.is_file():
        failed.append(rec['source_id']);continue
    ok=p.stat().st_size==rec['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==rec['sha256']
    print(rec['source_id'], 'MATCH' if ok else 'MISMATCH')
    if not ok:failed.append(rec['source_id'])
sys.exit(bool(failed))
