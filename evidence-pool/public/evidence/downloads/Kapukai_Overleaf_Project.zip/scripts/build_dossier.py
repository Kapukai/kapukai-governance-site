from pathlib import Path
import json, csv, re, shutil, hashlib, datetime

BASE=Path(__file__).resolve().parent
PACKAGED=BASE.name=='scripts'
OUT=BASE.parent if PACKAGED else BASE/'dossier_project'
INPUT=OUT/'data' if PACKAGED else BASE
OUT.mkdir(exist_ok=True)
def tex(s):
    s=str(s).replace('–','--').replace('—','---').replace('’',"'").replace('‘',"'").replace('“','``').replace('”',"''").replace('\u00a0',' ').replace('≥',r'$\geq$')
    return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in s)
def cite(ids): return r' \cite{'+','.join(ids)+'}' if ids else ''
def para(s, ids=[]):return tex(s)+cite(ids)+'\n\n'
def write(name,s):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def csvwrite(name,fields,rows):
    p=OUT/'data'/name;p.parent.mkdir(exist_ok=True)
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

groups=[]
for name in ['historical','recent','woolsey_russia','comparators','controls']:
    p=INPUT/f'research_{name}.json'
    if p.exists():groups.append((name,json.loads(p.read_text())))
sources=[s for _,g in groups for s in g['sources']]
for s in sources:
    for key in ['ref','web_ref','pdf_ref']:s.pop(key,None)
    s['limitations']=re.sub(r' Keep (?:total |all )?derived (?:prose|narrative).*?200 words\.', '',s.get('limitations',''))
    s['limitations']=s['limitations'].replace(' Keep all derived prose, including repeated assertions, under 200 words.','').replace('; short derivation only (25-word source limit)','')
cases=[c for _,g in groups for c in g.get('cases',[])]
controls=next(g for n,g in groups if n=='controls')
sourceby={s['id']:s for s in sources}
write('data/research.json',json.dumps({'as_of':'2026-10-01','sources':sources,'cases':cases,'domains':controls['domains'],'guidance':controls['guidance']},indent=2))
csvwrite('sources.csv',['source_id','title','author','date','url','type','locator','scope','limitations','accessed'],[{'source_id':s['id'],**{k:s.get(k,'') for k in ['title','author','date','url','type','locator','scope','limitations']},'accessed':'2026-10-01'} for s in sources])
timeline=[];claims=[]
for c in cases:
    for i,e in enumerate(c['timeline'],1):
        timeline.append({'event_id':c['id']+f'-EV{i:02}','case_id':c['id'],'date':e['date'],'precision':'day' if re.fullmatch(r'\d{4}-\d{2}-\d{2}',e['date']) else 'partial_or_range','event':e['event'],'source_ids':';'.join(e['source_ids']),'accessed':'2026-10-01'})
    for i,cl in enumerate(c['claims'],1):
        claims.append({'claim_id':c['id']+f'-CL{i:02}','case_id':c['id'],**{k:cl[k] for k in ['claim','status','assessment']},'source_ids':';'.join(cl['source_ids'])})
csvwrite('timelines.csv',['event_id','case_id','date','precision','event','source_ids','accessed'],timeline)
csvwrite('claims.csv',['claim_id','case_id','claim','status','assessment','source_ids'],claims)
csvwrite('control_points.csv',['id','domain','hypothesis','evidence','alternatives','reviewer','control','source_ids'],[{**d,'source_ids':';'.join(d['source_ids'])} for d in controls['domains']])
requests=[]
for c in cases:
    for i,g in enumerate(c['gaps'],1):requests.append({'request_id':c['id']+f'-RQ{i:02}','case_id':c['id'],'record_needed':g,'custodian':'TO VERIFY','requested_on':'','reference_number':'','response_due':'','status':'Not requested','response_or_appeal':''})
csvwrite('records_requests.csv',['request_id','case_id','record_needed','custodian','requested_on','reference_number','response_due','status','response_or_appeal'],requests)

STYLE=r'''\documentclass[11pt,letterpaper]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{lmodern,microtype}
\usepackage[margin=0.72in,headheight=15pt]{geometry}
\usepackage{graphicx,xcolor,booktabs,longtable,array,tabularx,enumitem,needspace}
\usepackage[most]{tcolorbox}
\usepackage{tikz}
\usetikzlibrary{arrows.meta,positioning,fit,calc}
\usepackage{xurl}
\usepackage{hyperref}
\usepackage{fancyhdr,titlesec}
\definecolor{navy}{HTML}{142C45}
\definecolor{gold}{HTML}{9C772C}
\definecolor{pale}{HTML}{F1F5F8}
\definecolor{teal}{HTML}{216565}
\definecolor{ink}{HTML}{263545}
\hypersetup{colorlinks=true,linkcolor=navy,citecolor=teal,urlcolor=teal,pdfauthor={Kapukai Governance Lab},pdftitle={Evidence dossier and research atlas}}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\small\sffamily\color{navy}KAPUKAI GOVERNANCE LAB}
\fancyhead[R]{\small\sffamily RESEARCH EDITION / 01 OCT 2026}
\fancyfoot[L]{\footnotesize\color{gray}Proof before memory. / Public-source research}
\fancyfoot[R]{\thepage}
\setlength{\parindent}{0pt}\setlength{\parskip}{6pt}
\setlength{\emergencystretch}{3em}
\renewcommand{\arraystretch}{1.18}
\setlist[itemize]{leftmargin=1.4em,itemsep=3pt,topsep=3pt}
\setlist[enumerate]{leftmargin=1.5em,itemsep=4pt}
\titleformat{\section}{\Large\bfseries\sffamily\color{navy}}{\thesection}{0.65em}{}
\titleformat{\subsection}{\large\bfseries\sffamily\color{navy}}{\thesubsection}{0.6em}{}
\newtcolorbox{note}{colback=pale,colframe=navy,boxrule=0.5pt,arc=0pt,breakable,left=9pt,right=9pt,top=7pt,bottom=7pt}
\newcommand{\field}[1]{\textbf{#1}\par\vspace{0.26in}\hrule\vspace{0.08in}}
\newcommand{\cover}[3]{\begin{titlepage}\color{navy}\vspace*{0.35in}{\large\sffamily KAPUKAI GOVERNANCE LAB}\par\vspace{0.4in}{\color{gold}\rule{1.5in}{3pt}}\par\vspace{0.3in}{\Huge\bfseries\sffamily #1}\par\vspace{0.25in}{\Large #2}\par\vspace{0.5in}\begin{note}#3\end{note}\vfill{\large Research cutoff: October 1, 2026\\Version 1.0 | Source-checked working edition}\par\vspace{0.2in}{\small Prepared with AI-assisted research. Source authority, case relevance and document authenticity must be evaluated separately. This is a research resource, not a certification of facts or a legal filing.}\end{titlepage}}
\newcommand{\sourcesstart}{\clearpage\section*{Source register}\addcontentsline{toc}{section}{Source register}\small\begin{thebibliography}{W99}}
\newcommand{\sourcesend}{\end{thebibliography}\normalsize}
'''
write('preamble.tex',STYLE)

def references(selected=None):
    ss=sources if selected is None else [s for s in sources if s['id'] in selected]
    out=r'\sourcesstart'+'\n'
    for s in ss:
        out+=r'\bibitem['+s['id']+']{'+s['id']+'} '+tex(s['author'])+'. '+r'\textit{'+tex(s['title'])+'}. '+tex(s['date'])+'.\\\n'
        out+=r'\url{'+s['url']+'}\\\n'+r'\textbf{Type:} '+tex(s['type'])+r'. \textbf{Pinpoint:} '+tex(s['locator'])+'\\\n'+r'\textbf{Scope:} '+tex(s['scope'])+r' \textbf{Limit:} '+tex(s['limitations'])+'\n'
    return out+r'\sourcesend'+'\n'
write('content/references.tex',references())
write('sources.bib','\n\n'.join('@misc{'+s['id']+',\n title={'+tex(s['title'])+'},\n author={{'+tex(s['author'])+'}},\n howpublished={\\url{'+s['url']+'}},\n note={'+tex(s['date'])+'; accessed 2026-10-01}\n}' for s in sources))

intro=r'''\section{What this dossier establishes}
\begin{note}\textbf{The reviewed record does not establish one network connecting these deaths and disappearances.} It does establish particular historical abuses, individual crimes, official inquiries and important unresolved questions. Evidence supporting those narrower propositions is retained alongside evidence that weakens a broader allegation.\end{note}
This edition covers the supplied historical cases, the recent U.S. scientist/defense-personnel reports, selected Russian deaths, anomalous health incidents (AHIs), and three documented espionage or transnational-operation comparators. It is a bounded public-source review, not a complete investigative file, epidemiological study or finding that any reader is being targeted.

The original ranking of cases by how suspicious they seem has been replaced by claim-level assessments. A documented death, an official inquiry, a laboratory affiliation, an attributed family statement and a proven perpetrator are different facts. They should never share one undifferentiated confidence label.

\subsection{The strongest reusable conclusions}
\begin{itemize}
\item Olson's nonconsensual exposure is documented; the later homicide allegation requires separate proof. \cite{H01,H04}
\item A congressional request for information establishes an inquiry, not the truth of the media allegations it cites. The April 20, 2026 letter expressly described the reporting as unconfirmed. \cite{R01}
\item The Colby medical examiner's accidental-death opinion must be included in any fair review. \cite{H06}
\item The 2023 and 2025 AHI intelligence assessments were recalled in June 2026. Reusing their conclusions without that status change would mislead readers. The recall does not establish a specific attacker. \cite{W04}
\item Confirmed espionage cases show the value of direct evidence of access, transactions, communications and control failures. They do not supply missing causal links in other cases. \cite{P01,P03,P04}
\end{itemize}

\subsection{How to use the packet}
Read the case's status, chronology and claim review together. Follow each source ID to the source register and its pinpoint. The atlas describes the meaning of each connection; no unlabeled line should be interpreted as criminal coordination. The toolkit contains blank forms for a new case. The data folder holds editable CSV and JSON registers; the evidence manager is optional and works locally.

\section{Method, provenance and confidence}
\subsection{Five questions for every assertion}
\begin{enumerate}
\item \textbf{Observation:} What happened, where, and at what time? What was directly observed?
\item \textbf{Record:} Who created the evidence, by what process, and can that record be authenticated?
\item \textbf{Causation:} What connects the observed outcome to a proposed mechanism?
\item \textbf{Attribution:} What connects the mechanism to a specific actor, instruction or transaction?
\item \textbf{Review:} What contradicts the claim, what remains missing, and what would change the conclusion?
\end{enumerate}

\begin{longtable}{p{0.23\linewidth}p{0.70\linewidth}}
\toprule\textbf{Status} & \textbf{Meaning in this edition}\\\midrule
Documented & A record supports the narrow proposition. An official statement is proof of that statement, not automatically every underlying allegation.\\
Reported / attributed & A named person or publication reports a fact; original record not acquired or independently confirmed.\\
Disputed & Material records or interpretations conflict. State each version and its provenance.\\
Unresolved & Evidence is insufficient to choose among reasonable explanations.\\
Unsupported inference & The reviewed evidence does not bridge the asserted causal or attribution step. This is not a declaration that the proposition is impossible.\\
Superseded & A dated later record changes an earlier report's status. Keep both in the correction history.\\\bottomrule
\end{longtable}

\subsection{Selection and statistical significance}
The case list was supplied by the requester and expanded to audit those claims. It is not a random or complete sample. Deaths, disappearances, occupations and time spans are heterogeneous; published totals change with inclusion rules. No excess mortality, statistical significance, common clearance status or common perpetrator can be calculated from that list alone.

Before testing a cluster, register a population and observation period in advance, obtain a denominator and comparable age/sex/cause-specific rates, define inclusion/exclusion rules, deduplicate people, measure missingness and separate discoveries from confirmations. Report uncertainty and multiple-comparison effects. A statistician should review the design before any numerical claim of excess risk is published. This is an author-created research protocol, not a finding from the case list.

\subsection{What was and was not collected}
Sources were located through current web search and inspected as public pages or documents. Some were available only through news reporting, a mirror, or an indexed extract; those limits are recorded. Selected public government PDFs are archived with acquisition metadata and SHA-256 hashes. They are not certified custodian copies. Other source IDs are citations only, not collected exhibits. No interviews, physical examinations, classified review, subpoena returns or private clinical records were obtained.

Retrieval date and research cutoff are October 1, 2026. Event dates and publication dates are kept separate. A missing later result means this review did not locate one, not that none exists. No agency, witness or record custodian was contacted. Recheck current status before a filing or public accusation.

\subsection{Public transparency pool}
Publish a reviewed claim register, lawful public sources, redacted derivatives and a visible correction history. Preserve restricted originals separately. A public Git repository is a publication channel and may be copied indefinitely; deleting a later commit cannot recall copies. Public submissions should enter a review queue with a source URL, exact claim, pinpoint, contradiction and disclosure permission, not automatic publication. A claim's status may move in either direction when new evidence arrives.
'''
write('content/method.tex',intro)

case_sections=''
for group,g in groups:
    if not g.get('cases'):continue
    groupname={'historical':'Historical intelligence cases','recent':'Recent U.S. scientist and defense-personnel reports','woolsey_russia':'Woolsey, anomalous health incidents and selected Russian deaths','comparators':'Documented comparators: what direct linkage looks like'}[group]
    case_sections+=r'\clearpage\section{'+tex(groupname)+'}\n'
    if group=='recent':
        ca=g.get('cluster_assessment',{})
        case_sections+=para(ca.get('summary',''),ca.get('source_ids',[]))
        case_sections+=para('Case statuses below are limited to the dated sources reviewed. The roster is an audit of public claims, not a verified victim set or proof of a common clearance level.')
    if group=='recent':
        for cl in g.get('cluster_assessment',{}).get('claims',[]):
            case_sections+=r'\textbf{'+tex(cl['claim'])+'} '+para(cl['assessment'],cl['source_ids'])
    for ci,c in enumerate(g['cases']):
        case_sections+=(r'\clearpage' if ci else '')+r'\subsection{'+tex(c['name'])+'}\n'+r'\texttt{'+tex(c['id'])+'}\n'
        case_sections+=r'\begin{note}\textbf{Status.} '+tex(c['status'])+r'\end{note}'+'\n'+para(c['summary'],c.get('source_ids',[]))
        case_sections+=r'\subsubsection*{Chronology}'+'\n'+r'\begin{longtable}{p{0.18\linewidth}p{0.75\linewidth}}\toprule\textbf{Date} & \textbf{Event and source}\\\midrule\endhead'+'\n'
        for e in c['timeline']:case_sections+=tex(e['date'])+' & '+tex(e['event'])+cite(e['source_ids'])+r'\\'+'\n'
        case_sections+=r'\bottomrule\end{longtable}'+'\n'+r'\subsubsection*{Claim review}'+'\n'
        for cl in c['claims']:
            case_sections+=r'\needspace{5\baselineskip}\textbf{'+tex(cl['claim'])+'}\\\n'+r'\textit{'+tex(cl['status'])+'}. '+para(cl['assessment'],cl['source_ids'])
        case_sections+=r'\subsubsection*{Records still needed}\begin{itemize}'+'\n'
        for gap in c['gaps']:case_sections+=r'\item '+tex(gap)+'\n'
        case_sections+=r'\end{itemize}\textbf{Research significance.} '+para(c['significance'])
write('content/cases.tex',case_sections)

controltex=r'\clearpage\section{Defensive control-point register}'+'\n'
controltex+=para(controls['guidance'][0]['text'])
controltex+=para('These twenty domains cover technical, institutional, physical, medical and biological evidence pathways. They are not probabilities, a diagnostic checklist or a claim that every control point is compromised. For chemical, biological or clinical questions, record observations and seek qualified assessment; this packet supplies no methods for creating, delivering or concealing harmful agents.')
for d in controls['domains']:
    controltex+=r'\needspace{13\baselineskip}\subsection{'+tex(d['id']+' / '+d['domain'])+'}\n'
    for title,key in [('Hypothesis to test','hypothesis'),('Evidence to seek','evidence'),('Alternative explanations','alternatives'),('Qualified review','reviewer'),('Defensive control','control')]:controltex+=r'\textbf{'+title+':} '+tex(d[key])+r'\par'+'\n'
    controltex+='Standards informing this review prompt:'+cite(d['source_ids'])+'\n\n'
write('content/controls.tex',controltex)

guidetex=r'\clearpage\section{Evidence preservation and reporting routes}'+'\n'
for g in controls['guidance'][1:]:guidetex+=r'\subsection{'+tex(g['topic'])+'}\n'+para(g['text'],g['source_ids'])
guidetex+=r'''\subsection{A practical first review}
Choose one verifiable adverse event. Write one neutral paragraph. Identify the best original record and the person or office that controls it. Preserve the record and its metadata. Identify one plausible alternative explanation and one piece of evidence that would distinguish it. Only then expand the event into a timeline or link it to another case.

When an urgent health or safety issue exists, obtaining care or appropriate emergency assistance takes priority over completing the packet. Health symptoms and technical anomalies deserve examination without first assuming an attacker or a mechanism.

\subsection{Limits of this edition}
This work does not exhaust the available archives or rank every death. It has not authenticated every mirrored record, acquired full case files, proved individual exposure, measured a mortality cluster, or established current legal rights for a particular person. Its value is a traceable starting record and a disciplined way to add evidence, contradictions and corrections.
'''
write('content/guidance.tex',guidetex)
write('main.tex',r'''\input{preamble.tex}
\begin{document}
\cover{Evidence,\newline authority\newline and attribution}{Case dossier and research register}{Historical intelligence cases, recent scientist reports, anomalous health incidents, and documented espionage comparators. Each proposition has its own evidence threshold.}
{\small\tableofcontents}\clearpage
\input{content/method.tex}
\input{content/cases.tex}
\input{content/controls.tex}
\input{content/guidance.tex}
\input{content/references.tex}
\end{document}
''')

toolkit=r'''\input{preamble.tex}
\begin{document}
\cover{Build a case\newline that can\newline be checked}{Reusable evidence toolkit}{Blank forms, narrative structure, evidence intake, record requests, competing hypotheses, corrections and publication review. Adapt each form to actual records.}
{\small\tableofcontents}\clearpage
\section{Start here}
Create one case identifier. Keep event dates separate from dates when you learned about them. Preserve original files and make separate working or redacted copies. Use only lawful access. The templates do not create legal privilege, protection, admissibility or a finding of wrongdoing.\cite{C03,C06,C22}

\begin{note}The forms below are intentionally blank. They contain no allegation that any specific reader is targeted. Do not import case facts from another person's story into your own statement. A similar pattern is a lead to test.\end{note}
\textbf{Suggested folder convention:} originals, working copies, redacted public copies, source register, claims, timelines, requests, review and releases. The optional Python manager uses its own documented case-folder structure. Hashes support byte-integrity checks; they do not prove truth or collection authenticity.

\section{Evidence intake and file integrity}
The local tool copies a supplied file, assigns an exhibit ID, records a SHA-256 digest and adds a custody event. It does not image a device, preserve every filesystem attribute or create an immutable forensic repository. Follow its README before use. For a potentially compromised device, obtain qualified collection advice before changing settings or running tools on it.\cite{C03}
\begin{verbatim}
python3 scripts/evidence_manager.py init /path/to/CASE-001
python3 scripts/evidence_manager.py add /path/to/CASE-001 \
  /path/to/record.pdf --case CASE-001 --title "Original notice" \
  --collector "Collector name" --source "Record custodian" \
  --access restricted
python3 scripts/evidence_manager.py verify /path/to/CASE-001
\end{verbatim}
Keep confidential material out of the public repository. Overleaf receives only material appropriate for that service and its sharing settings; classified material requires an approved channel.\cite{C07,C19}

\clearpage\section{Case opening sheet}
\field{Case identifier / neutral short title}
\field{Prepared by / version / date / reviewer}
\field{Observed problem in one sentence}
\field{Relevant place, date range and time zone}
\field{What decision, loss, injury or disappearance is at issue?}
\field{What outcome or correction is requested?}
\field{Who can lawfully access the originals?}
\field{Known deadlines and source of each deadline}
\field{Confidential identifiers stored separately / reference only}

\clearpage\section{Neutral incident narrative}
\textbf{Structure:} observation, source, consequence, uncertainty, request.
\begin{note}On [event date/time/time zone], I [directly observed / received / was informed of] [specific event]. The supporting record is [exhibit ID, title, pinpoint]. [Decision or consequence] followed on [date]. I can verify [facts]. I cannot presently verify [mechanism/identity/intent]. [Alternative explanation] remains possible because [reason]. I request [specific existing records, independent review or correction].\end{note}
\field{What I personally observed}
\field{What another person told me, and who/when}
\field{What a document states, with exhibit and pinpoint}
\field{My inference, identified explicitly as an inference}
\field{Evidence that may contradict my account}
\field{What would resolve the uncertainty?}

\clearpage\section{Claim and predicate worksheet}
\field{Claim ID / exact proposition to test}
\field{Necessary elements: event, mechanism, actor, intent, authority}
\field{Evidence supporting each element / pinpoint}
\field{Evidence against each element / pinpoint}
\field{Source independence: common origin or independent observation?}
\field{Alternative explanation and discriminating evidence}
\field{Current status / confidence rationale / review date}
\field{Next lawful collection step / owner / target date}

\clearpage\section{Timeline entry}
\field{Event ID / case ID}
\field{Event date, time, zone and precision (exact, approximate, range)}
\field{Date recorded / date learned / date retrieved}
\field{Neutral event description}
\field{Source ID / exhibit ID / page or timestamp}
\field{Direct observation, attributed account or inference?}
\field{Conflicting dates and why they differ}
\field{Related decision or consequence; link supported by what evidence?}
\field{Reviewer / status / next check}

\clearpage\section{Exhibit and custody record}
\field{Exhibit ID / original filename / title}
\field{Creator, custodian and originating system}
\field{How and when lawfully acquired / time zone}
\field{File format, bytes, SHA-256 / tool version}
\field{Authenticity indicators and limitations}
\field{Transfer: from, to, date, purpose, receipt}
\field{Derived copies: conversion/redaction and new hash}
\field{Storage location, access class and backup verification}
\field{Certification requested from custodian?}

\clearpage\section{Source card and independence test}
\field{Source ID / author / institution / title / publication date}
\field{URL / archive URL / retrieval date / local exhibit ID}
\field{Exact page, paragraph, section or timestamp}
\field{Which precise claim does this source support?}
\field{Primary record, later account, advocacy, analysis or hearsay?}
\field{Does it quote another source? Trace to the earliest available record.}
\field{What it does not establish / conflicts / correction history}
\field{Copyright and public-release basis}

\clearpage\section{Connection record}
\begin{note}A relationship label must state what is actually supported: employment, contract, communication, payment, access, co-presence, oversight or an attributed allegation. Avoid a generic ``connected to'' edge.\end{note}
\field{Edge ID / entity A / entity B / identity disambiguation}
\field{Relationship type and direction}
\field{Dates active / source and pinpoint}
\field{Documented, reported, disputed or hypothetical?}
\field{Does this establish opportunity, mechanism or actual action?}
\field{Alternative explanation / evidence needed to upgrade or remove edge}
\field{Publication review and privacy constraints}

\clearpage\section{Competing hypotheses}
For each hypothesis list a predicted observation, evidence found, contrary evidence, missing evidence and a lawful discriminating test. Do not count repeated news stories as independent corroboration.
\field{H1: ordinary accident, illness, error or authorized action}
\field{H2: individual criminal act or misconduct}
\field{H3: coordinated conduct by identified actors}
\field{H4: other explanation supported by a concrete observation}
\field{Evidence that would most strongly distinguish H1--H4}
\field{What finding would lower confidence in my preferred hypothesis?}
\field{Independent reviewer / review result}

\clearpage\section{Retaliation chronology}
This worksheet separates sequence from causation. Forum, worker coverage and protected-disclosure requirements differ. Check the relevant office and deadlines.\cite{C06,C18,C22,C23}
\field{Disclosure or protected activity / content / recipient / date}
\field{Receipt and evidence the decision-maker knew}
\field{Personnel action / date / stated reason / decision-maker}
\field{Prior performance and comparable treatment records}
\field{Evidence connecting activity to action; evidence against connection}
\field{Other explanations / requested records}
\field{Applicable forum, deadline, counsel or independent advice}

\clearpage\section{Health or exposure chronology}
Record symptoms and circumstances without presuming a biological, chemical or directed-energy cause. Qualified clinicians and exposure specialists should interpret measurements. Do not collect hazardous material yourself.\cite{C09,C13,C15}
\field{Symptoms: onset, duration, location and ordinary activities}
\field{Contemporaneous clinical observations and test reports}
\field{Potential exposures actually observed / calibrated measurements}
\field{Medication, medical and environmental alternatives to assess}
\field{Who collected samples / methods / custody / laboratory controls}
\field{Clinical assessment, uncertainty and follow-up}
\field{Evidence needed for exposure, dose, mechanism and attribution}

\clearpage\section{Existing-record request draft}
Use the appropriate agency, state, court or private-record route. Federal FOIA concerns existing records and does not require an agency to conduct research to answer a theory.\cite{C16,C17}
\begin{note}To: [verified records office]\par
I request copies of existing [record types] for [date range] concerning [specific event/file number], likely maintained by [custodian/system]. Please include [specific metadata, versions or attachments] where retained. My scope excludes [unnecessary personal information]. If parts are withheld, please identify the applicable basis and provide any reasonably segregable material. Please advise concerning fees before exceeding [amount]. Please send the tracking number and instructions for any applicable review or appeal.\par
[Name and safe contact channel appropriate to the request]\end{note}
\field{Request ID / date / delivery and receipt proof}
\field{Scope and custodian confirmed how?}
\field{Response, withholding grounds or no-records result}
\field{Clarification / appeal / deadline and authority}
\field{What the response changes in the claim register}

\clearpage\section{Preservation request draft}
This is a request template, not a claim that every recipient has a specific legal duty. Tailor any asserted duty or litigation hold with qualified advice.
\begin{note}Please preserve existing records relevant to [specific event/decision and date range], including [identified records], associated metadata, audit logs and retained versions. Please avoid routine deletion or overwriting of responsive material while the scope and appropriate process are clarified. This request does not ask you to create new evidence or disclose material through an unauthorized channel. Please identify a records contact and acknowledge receipt.\end{note}
\field{Recipient and basis for believing records are held there}
\field{Specific systems, records and dates}
\field{Known retention schedule or overwrite risk}
\field{Request, receipt, response and follow-up}

\clearpage\section{Correction and downstream propagation}
\field{Correction ID / original assertion / version / publication locations}
\field{New evidence and source pinpoint}
\field{Corrected assertion and reason}
\field{Which timelines, maps, summaries and decisions relied on it?}
\field{Who must receive the correction and through what authorized route?}
\field{Date sent / receipt / downstream correction verified}
\field{Unresolved differences / next review}

\clearpage\section{Public-release review}
\field{Release ID / version / reviewer / approval date}
\field{Each factual claim has a source and status?}
\field{Contrary evidence and uncertainty retained?}
\field{Private identities, children, addresses, health records and credentials removed?}
\field{Redactions irreversible in the released derivative and metadata inspected?}
\field{Authority, consent or lawful basis to publish each exhibit?}
\field{Classification, court restrictions and third-party rights checked?}
\field{Hashes, source register and correction route present?}
\field{Public repository contents reviewed separately from private folder?}

\clearpage\section{Witness account for review}
This is an unsigned narrative template. It is not a notarized affidavit or a jurisdiction-specific declaration. Do not add an oath, signature block or penalty-of-perjury language without choosing the correct legal form and reviewing the facts.
\field{Name or protected identifier / relationship to events}
\field{Facts personally known, in numbered paragraphs}
\field{Records used to refresh recollection, with exhibits}
\field{Statements learned from others, identified separately}
\field{Limitations, approximations and corrections}
\field{Safe contact through authorized reviewer}
\field{Legal form / competent reviewer / signature process to determine}
'''
toolkit+=references({s for g in controls['guidance'] for s in g['source_ids']} | {'C03','C06','C09','C13','C15','C18','C22','C23'})+r'\end{document}'
write('toolkit.tex',toolkit)

write('latexmkrc',"$pdf_mode = 1;\n$pdflatex = 'pdflatex -interaction=nonstopmode -halt-on-error %O %S';\n")
write('scripts/build_all.sh','#!/usr/bin/env bash\nset -euo pipefail\ncd "$(dirname "$0")/.."\nmkdir -p compiled\nfor name in main atlas toolkit; do\n  latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=compiled "$name.tex"\ndone\n')
write('templates/case_template.tex',r'''% Copy this section into content/cases.tex; replace every bracketed field.
\subsection{[Neutral case name]}
\begin{note}\textbf{Status.} [Narrow finding, uncertainty, review date.]\end{note}
[Neutral summary.]
\subsubsection*{Chronology}
\begin{longtable}{p{0.18\linewidth}p{0.75\linewidth}}
\toprule Date & Event and source\\\midrule
[YYYY-MM-DD] & [Event, observation type, source ID and pinpoint.]\\
\bottomrule\end{longtable}
\subsubsection*{Claims and contrary evidence}
[One proposition per paragraph; identify source and competing explanation.]
\subsubsection*{Records needed}
\begin{itemize}\item [Record, custodian, lawful route.]\end{itemize}
''')
write('templates/case_template.json',json.dumps({'id':'CASE-NEW','name':'Neutral case title','summary':'','status':'Unreviewed','timeline':[],'claims':[],'gaps':[],'significance':'','source_ids':[]},indent=2))
write('data/corrections.csv','correction_id,case_id,old_version,old_claim,new_claim,reason,source_ids,reviewer,date,downstream_locations,verified\n')
write('data/custody_template.csv','exhibit_id,utc_time,from_custodian,to_custodian,action,purpose,sha256_before,sha256_after,receipt,notes\n')
write('data/publication_review.csv','release_id,artifact,source_checked,contrary_evidence_checked,privacy_checked,rights_checked,classification_checked,reviewer,approval_date,public_url,hash\n')
write('README_FIRST.md',f'''# Kapukai evidence dossier and atlas - v1.0

Research cutoff: 2026-10-01. This is a bounded public-source research edition, not proof of a single network or of anyone's personal targeting.

## Read
- `compiled/main.pdf`: case dossier, timelines, claim reviews, controls and source register.
- `compiled/atlas.pdf`: connection maps with typed edges and limitations.
- `compiled/toolkit.pdf`: reusable blank research and evidence forms.

## Overleaf
1. Download the Overleaf ZIP and choose **New Project > Upload Project**.
2. Select **pdfLaTeX** and choose `main.tex` as the main document.
3. Recompile. Choose `atlas.tex` or `toolkit.tex` as the main document to compile each companion.
4. All diagrams are native LaTeX/TikZ. No shell escape, paid package, external API or BibTeX run is required.

For local builds, install a normal TeX Live distribution with latexmk and run `bash scripts/build_all.sh` from the project. PDFs are written to `compiled/`. On Overleaf, each selected main document generates its own downloadable PDF. Overleaf does not run the Python evidence manager.

## Edit and extend
Edit the generated `.tex` files directly, or edit the five `data/research_*.json` input files and run `python3 scripts/build_dossier.py`, then `python3 scripts/build_atlas.py`, then `bash scripts/build_all.sh`. The combined `data/research.json` and CSVs are generated outputs. Do not mix direct edits and regeneration without a backup. Each claim needs a source ID, pinpoint and status; each relationship needs a typed edge. `sources.bib` is supplied for reuse, while this edition uses an in-document source register. The CSV registers can be opened in a spreadsheet.

## Evidence storage
The Overleaf ZIP contains public research and forms only. The full research-system ZIP additionally contains selected public government source PDFs, provenance records and the local evidence manager. Citation-only sources are not claimed to be collected originals. A downloaded PDF is not a certified custodian copy.

For your own case use a separate local folder with `scripts/evidence_manager.py`; read its README before use. The tool copies input files; it does not move or delete them. Restricted originals must remain out of public GitHub and ordinary Overleaf projects. Do not add classified, sealed or otherwise restricted material to this public project. No passwords, identity documents, medical files or private allegations were included in this edition.

## Public transparency pool
The public website edition is prepared separately. Public-source submissions should be reviewed before publication. Maintain a correction log and update all affected timelines and maps. This packet makes no claim that a website or GitHub repository has been deployed.

## Verification and scope
Read `qa/BUILD_REPORT.md` for actual compilation and checks. There are {len(cases)} case/context modules, {len(sources)} source records and {len(controls['domains'])} defensive control domains in the data. Scope includes some secondary reports and mirrored primary records; read source-specific limits. Source URLs can change. No agency contacts or records requests have been sent.

Original Kapukai-authored templates and software are provided for reuse and adaptation. Third-party source documents retain their own legal status; no blanket license is granted for them. Preserve attribution and clearly mark changes.
''')
print(json.dumps({'cases':len(cases),'sources':len(sources),'events':len(timeline),'claims':len(claims),'requests':len(requests)}))
