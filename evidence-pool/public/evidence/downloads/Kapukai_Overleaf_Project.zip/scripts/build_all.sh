#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p compiled
for name in main atlas toolkit; do
  latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=compiled "$name.tex"
done
