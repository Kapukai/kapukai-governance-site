#!/usr/bin/env python3
"""Local evidence intake and integrity checks. Python 3.9+; standard library only.

Hashes show byte consistency, not truth, authenticity, lawful collection, or
causation. This is an ordinary application, not a forensic write blocker.
"""
import argparse
import contextlib
import csv
import datetime as dt
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import stat
import sys
import tempfile
import uuid

SCHEMA = 1
HEX = re.compile(r"^[0-9a-f]{64}$")
IDENT = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$")
EXHIBIT = re.compile(r"^EX-[0-9]{8}-[0-9a-f]{16}$")
NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)


class EvidenceError(Exception):
    pass


def utc_now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def no_symlinks(path, must_exist=True):
    """Reject symlink components; this does not claim immunity to hostile races."""
    path = Path(os.path.abspath(os.fspath(path)))
    for part in (list(path.parents)[::-1] + [path]):
        try:
            mode = part.lstat().st_mode
        except FileNotFoundError:
            if must_exist:
                raise EvidenceError("Path does not exist: " + str(part))
            continue
        if stat.S_ISLNK(mode):
            raise EvidenceError("Symlinks are refused: " + str(part))
    return path


def regular_file(path):
    path = no_symlinks(path)
    if not stat.S_ISREG(path.stat().st_mode):
        raise EvidenceError("Expected a regular file: " + str(path))
    return path


def read_bytes(path):
    regular_file(path)
    fd = os.open(path, os.O_RDONLY | NOFOLLOW)
    with os.fdopen(fd, "rb") as handle:
        if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode):
            raise EvidenceError("Expected a regular file")
        return handle.read()


def sync_directory(path):
    if os.name == "posix":
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def atomic_write(path, data, replace=False, mode=0o600):
    no_symlinks(path.parent)
    no_symlinks(path, must_exist=False)
    fd, tmp_name = tempfile.mkstemp(prefix=".pending-", dir=path.parent)
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp, mode)
        if replace:
            # Destination was checked above; do not run this in a hostile shared directory.
            os.replace(tmp, path)
        else:
            # Atomic, exclusive publication: never overwrite a pre-existing pathname.
            os.link(tmp, path)
            tmp.unlink()
        sync_directory(path.parent)
    finally:
        if tmp.exists():
            tmp.unlink()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


@contextlib.contextmanager
def lock(root):
    path = root / ".evidence-manager.lock"
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | NOFOLLOW, 0o600)
    except FileExistsError:
        raise EvidenceError("Case is locked. If a process crashed, confirm no manager is running before manually removing .evidence-manager.lock.")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write("pid=" + str(os.getpid()) + "\nstarted_utc=" + utc_now() + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        yield
    finally:
        path.unlink()


def case_root(path):
    root = no_symlinks(path)
    if not root.is_dir():
        raise EvidenceError("Case directory is not a directory")
    return root


def safe_evidence_path(root, relative):
    if not isinstance(relative, str) or "\\" in relative or "\x00" in relative:
        raise EvidenceError("Invalid exhibit path")
    parts = PurePosixPath(relative).parts
    if (PurePosixPath(relative).is_absolute() or PureWindowsPath(relative).is_absolute()
            or len(parts) != 3 or parts[:2] != ("evidence", "originals")
            or any(p in ("", ".", "..") for p in parts)
            or ":" in parts[-1] or str(PurePosixPath(relative)) != relative):
        raise EvidenceError("Unsafe exhibit path: " + repr(relative))
    return no_symlinks(root.joinpath(*parts))


def load_manifest(root):
    try:
        data = json.loads(read_bytes(root / "manifest.json").decode("utf-8"))
    except (ValueError, UnicodeError) as exc:
        raise EvidenceError("Invalid manifest JSON: " + str(exc))
    if not isinstance(data, dict) or data.get("schema_version") != SCHEMA or not isinstance(data.get("exhibits"), list):
        raise EvidenceError("Unsupported or malformed manifest")
    ids, paths = set(), set()
    for entry in data["exhibits"]:
        if not isinstance(entry, dict):
            raise EvidenceError("Malformed exhibit entry")
        for key in ("exhibit_id", "case_id", "title", "collector", "source", "event_date", "access",
                    "original_name", "relative_path", "sha256", "acquired_utc", "provenance_note"):
            if not isinstance(entry.get(key), str) or "\x00" in entry[key]:
                raise EvidenceError("Invalid or missing exhibit field: " + key)
        if (not EXHIBIT.fullmatch(entry["exhibit_id"]) or not IDENT.fullmatch(entry["case_id"])
                or not HEX.fullmatch(entry["sha256"]) or entry["access"] not in ("public", "restricted")
                or type(entry.get("byte_size")) is not int or entry["byte_size"] < 0):
            raise EvidenceError("Invalid exhibit identifier, hash, size, or access level")
        path = safe_evidence_path(root, entry["relative_path"])
        if not path.name.startswith(entry["exhibit_id"]):
            raise EvidenceError("Exhibit filename does not match its identifier")
        if entry["exhibit_id"] in ids or entry["relative_path"] in paths:
            raise EvidenceError("Duplicate exhibit identifier or path")
        ids.add(entry["exhibit_id"])
        paths.add(entry["relative_path"])
    return data


def load_chain(root):
    chain = []
    previous = "0" * 64
    try:
        lines = read_bytes(root / "chain-of-custody.jsonl").decode("utf-8").splitlines()
        for seq, line in enumerate(lines, 1):
            event = json.loads(line)
            if not isinstance(event, dict):
                raise EvidenceError("Malformed custody event")
            digest = event.get("event_sha256")
            payload = {k: v for k, v in event.items() if k != "event_sha256"}
            if (event.get("sequence") != seq or event.get("previous_event_sha256") != previous
                    or digest != hashlib.sha256(canonical(payload)).hexdigest()):
                raise EvidenceError("Custody log integrity failure at sequence " + str(seq))
            if not isinstance(event.get("utc"), str) or event.get("action") not in ("init", "add"):
                raise EvidenceError("Malformed custody action")
            chain.append(event)
            previous = digest
    except (ValueError, UnicodeError) as exc:
        raise EvidenceError("Invalid custody log: " + str(exc))
    if not chain or chain[0]["action"] != "init" or any(e["action"] == "init" for e in chain[1:]):
        raise EvidenceError("Custody log must start with exactly one init event")
    return chain


def append_chain(root, chain, action, details):
    event = {"sequence": len(chain) + 1, "utc": utc_now(), "action": action,
             "previous_event_sha256": chain[-1]["event_sha256"] if chain else "0" * 64,
             "details": details}
    event["event_sha256"] = hashlib.sha256(canonical(event)).hexdigest()
    fd = os.open(root / "chain-of-custody.jsonl", os.O_WRONLY | os.O_APPEND | NOFOLLOW)
    with os.fdopen(fd, "ab") as handle:
        handle.write(canonical(event) + b"\n")
        handle.flush()
        os.fsync(handle.fileno())


def init_case(directory):
    root = no_symlinks(directory, must_exist=False)
    # Existing directories are refused, including empty directories; this avoids mixing cases.
    root.mkdir(mode=0o700, parents=False, exist_ok=False)
    (root / "evidence").mkdir(mode=0o700)
    (root / "evidence" / "originals").mkdir(mode=0o700)
    (root / "evidence" / "derivatives").mkdir(mode=0o700)
    atomic_write(root / "manifest.json", json_bytes({"schema_version": SCHEMA, "created_utc": utc_now(), "exhibits": []}))
    atomic_write(root / "chain-of-custody.jsonl", b"")
    append_chain(root, [], "init", {"schema_version": SCHEMA})
    print("Initialized private case directory: " + str(root))


def hash_file(path):
    regular_file(path)
    fd = os.open(path, os.O_RDONLY | NOFOLLOW)
    digest, size = hashlib.sha256(), 0
    with os.fdopen(fd, "rb") as handle:
        if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode):
            raise EvidenceError("Expected regular exhibit file")
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
            size += len(block)
    return digest.hexdigest(), size


def inspect_case(root):
    manifest, chain = load_manifest(root), load_chain(root)
    problems = []
    records = {e["exhibit_id"]: e for e in manifest["exhibits"]}
    logged = {}
    for event in chain[1:]:
        details = event.get("details")
        if not isinstance(details, dict) or not isinstance(details.get("exhibit_id"), str):
            problems.append("Malformed custody add details")
            continue
        eid = details["exhibit_id"]
        if eid in logged:
            problems.append("Duplicate custody add: " + eid)
        logged[eid] = details
    if set(records) != set(logged):
        problems.append("Manifest and custody log exhibit sets differ")
    known = set()
    for eid, entry in records.items():
        path = safe_evidence_path(root, entry["relative_path"])
        known.add(path.name)
        digest, size = hash_file(path)
        if digest != entry["sha256"] or size != entry["byte_size"]:
            problems.append("Bytes changed: " + eid)
        if eid in logged and logged[eid].get("record_sha256") != hashlib.sha256(canonical(entry)).hexdigest():
            problems.append("Manifest metadata differs from custody record: " + eid)
    originals = no_symlinks(root / "evidence" / "originals")
    for path in originals.iterdir():
        if path.name not in known:
            problems.append("Unregistered file or directory in originals: " + path.name)
    return manifest, chain, problems


def require_clean(root):
    manifest, chain, problems = inspect_case(root)
    if problems:
        raise EvidenceError("Integrity check failed:\n" + "\n".join(problems))
    return manifest, chain


def validate_event_date(value):
    if not value:
        return ""
    try:
        if len(value) == 10:
            dt.date.fromisoformat(value)
        else:
            parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                raise ValueError("timestamp requires a timezone")
    except ValueError:
        raise EvidenceError("--event-date must be YYYY-MM-DD or an ISO timestamp with a timezone")
    return value


def add_file(args):
    root = case_root(args.case_dir)
    source_file = regular_file(args.file)
    if root == source_file or root in source_file.parents:
        raise EvidenceError("Intake source must be outside the case directory")
    if not IDENT.fullmatch(args.case):
        raise EvidenceError("--case must be 1–80 letters, digits, periods, underscores, or hyphens, starting with a letter/digit")
    for value in (args.title, args.collector, args.source):
        if not value.strip() or "\x00" in value:
            raise EvidenceError("Title, collector, and source must be nonempty and contain no NUL")
    event_date = validate_event_date(args.event_date)
    suffix = source_file.suffix
    if any(c in suffix for c in ("\\", ":", "\x00")):
        raise EvidenceError("Source extension contains nonportable path characters; create a documented derivative with a portable filename")
    with lock(root):
        manifest, chain = require_clean(root)
        eid = "EX-" + dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d") + "-" + uuid.uuid4().hex[:16]
        relative = "evidence/originals/" + eid + suffix
        destination = root / relative
        fd, tmp_name = tempfile.mkstemp(prefix=".pending-", dir=destination.parent)
        temp = Path(tmp_name)
        try:
            source_fd = os.open(source_file, os.O_RDONLY | NOFOLLOW)
            digest, size = hashlib.sha256(), 0
            with os.fdopen(source_fd, "rb") as inp, os.fdopen(fd, "wb") as out:
                before = os.fstat(inp.fileno())
                if not stat.S_ISREG(before.st_mode):
                    raise EvidenceError("Source ceased to be a regular file")
                for block in iter(lambda: inp.read(1024 * 1024), b""):
                    out.write(block)
                    digest.update(block)
                    size += len(block)
                after = os.fstat(inp.fileno())
                if (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_size, after.st_mtime_ns, after.st_ctime_ns):
                    raise EvidenceError("Source changed during intake; no exhibit was registered")
                out.flush()
                os.fsync(out.fileno())
            os.link(temp, destination)
            temp.unlink()
            os.chmod(destination, 0o444)
            sync_directory(destination.parent)
        finally:
            if temp.exists():
                temp.unlink()
        entry = {"exhibit_id": eid, "case_id": args.case, "title": args.title,
                 "collector": args.collector, "source": args.source,
                 "event_date": event_date, "access": args.access,
                 "original_name": source_file.name, "relative_path": relative,
                 "sha256": digest.hexdigest(), "byte_size": size, "acquired_utc": utc_now(),
                 "provenance_note": "Local copy; collector and source are user declarations, not independently authenticated."}
        manifest["exhibits"].append(entry)
        # These two files are not one transaction. verify detects an interrupted intake.
        append_chain(root, chain, "add", {"exhibit_id": eid, "case_id": args.case,
                     "sha256": entry["sha256"], "byte_size": size,
                     "record_sha256": hashlib.sha256(canonical(entry)).hexdigest()})
        atomic_write(root / "manifest.json", json_bytes(manifest), replace=True)
        print("Added " + eid + " (" + str(size) + " bytes; " + args.access + ")")


def verify_case(directory):
    root = case_root(directory)
    with lock(root):
        manifest, _ = require_clean(root)
    print("VERIFIED: " + str(len(manifest["exhibits"])) + " exhibit(s); stored hashes, sizes, metadata, and custody links agree.")
    print("This check does not establish authenticity, truth, a complete history, or an external timestamp.")


LATEX = {"\\": r"\textbackslash{}", "{": r"\{", "}": r"\}", "$": r"\$", "&": r"\&",
         "#": r"\#", "%": r"\%", "_": r"\_", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}


def latex_escape(value):
    chunks = []
    for char in str(value):
        if char in LATEX:
            chunks.append(LATEX[char])
        elif char in "\r\n\t":
            chunks.append(" ")
        elif not 32 <= ord(char) <= 126:
            chunks.append("[U+" + format(ord(char), "04X") + "]")
        else:
            chunks.append(char)
    return "".join(chunks)


def csv_safe(value):
    text = str(value)
    return "'" + text if text.lstrip().startswith(("=", "+", "-", "@")) or text.startswith(("\t", "\r", "\n")) else text


def export_source(value):
    # Avoid exposing local absolute paths supplied in the source field.
    trimmed = value.strip()
    if (trimmed.startswith(("/", "~/", "~\\", "\\\\", "file:"))
            or re.match(r"^[A-Za-z]:[\\/]", trimmed)):
        return "[Local source path omitted; review private provenance record]"
    return value


def catalog_tex(entries):
    lines = [r"\documentclass[11pt]{article}", r"\usepackage[T1]{fontenc}",
             r"\usepackage[margin=1in]{geometry}", r"\usepackage{longtable,array}",
             r"\setlength{\parindent}{0pt}", r"\begin{document}",
             r"\section*{Public Exhibit Metadata Catalog}",
             r"Original files are not included. Public metadata requires a privacy review before sharing.",
             r"A hash establishes byte consistency only; it does not establish truth or provenance.",
             r"Non-ASCII characters appear as U+ codes; the JSON register preserves their exact text.",
             "", "Export generated (UTC): " + latex_escape(utc_now()) + r"\par"]
    for entry in entries:
        lines.extend([r"\subsection*{" + latex_escape(entry["exhibit_id"]) + "}",
                      r"\begin{longtable}{>{\raggedright\arraybackslash}p{0.20\textwidth}>{\raggedright\arraybackslash}p{0.73\textwidth}}"])
        fields = [("Case", "case_id"), ("Title", "title"), ("Collector", "collector"),
                  ("Declared source", "source"), ("Original filename", "original_name"),
                  ("Declared event date", "event_date"), ("Acquired UTC", "acquired_utc"),
                  ("Bytes", "byte_size"), ("Access", "access")]
        for label, key in fields:
            lines.append(latex_escape(label) + " & " + latex_escape(entry[key] or "Not supplied") + r" \\")
        digest = entry["sha256"]
        lines.append("SHA-256 & " + r"\texttt{" + digest[:32] + r"}\newline\texttt{" + digest[32:] + r"} \\")
        lines.extend([r"\end{longtable}", ""])
    if not entries:
        lines.append(r"\par No exhibits have been designated public.")
    lines.append(r"\end{document}")
    return ("\n".join(lines) + "\n").encode("ascii")


def export_case(directory, output):
    root = case_root(directory)
    destination = no_symlinks(output, must_exist=False)
    if destination.exists():
        raise EvidenceError("Export destination already exists; choose a new directory")
    if root == destination or root in destination.parents:
        raise EvidenceError("Export destination must be outside the private case directory")
    no_symlinks(destination.parent)
    with lock(root):
        manifest, _ = require_clean(root)
        public = []
        for entry in manifest["exhibits"]:
            if entry["access"] == "public":
                safe = {k: v for k, v in entry.items() if k != "relative_path"}
                safe["source"] = export_source(safe["source"])
                public.append(safe)
        # Export files are atomically written in a newly created exclusive directory.
        destination.mkdir(mode=0o700, exist_ok=False)
        header = {"schema_version": SCHEMA, "exported_utc": utc_now(),
                  "scope": "Public-designated metadata only. No original files or private custody log included.",
                  "exhibits": public}
        atomic_write(destination / "exhibit-register.json", json_bytes(header))
        columns = ["exhibit_id", "case_id", "title", "collector", "source", "event_date", "access",
                   "original_name", "sha256", "byte_size", "acquired_utc", "provenance_note"]
        buf = io.StringIO(newline="")
        writer = csv.DictWriter(buf, fieldnames=columns)
        writer.writeheader()
        for entry in public:
            writer.writerow({k: csv_safe(entry[k]) for k in columns})
        atomic_write(destination / "exhibit-register.csv", buf.getvalue().encode("utf-8"))
        atomic_write(destination / "exhibit-catalog.tex", catalog_tex(public))
        atomic_write(destination / "READ-BEFORE-SHARING.txt", (
            "This export contains only metadata marked public, not originals.\n"
            "Inspect names, titles, collector details, URLs, and free text before sharing.\n"
            "Local paths occupying the entire source field are omitted. Embedded paths and sensitive prose require manual review.\n"
            "CSV prefixes potential spreadsheet formulas with an apostrophe; JSON preserves exact text except omitted local source paths.\n"
            "Compile exhibit-catalog.tex with pdfLaTeX (no shell escape needed).\n"
            "A successful integrity check cannot prove truth, provenance, independent timestamps, or an untampered complete history.\n"
        ).encode("utf-8"))
    print("Exported " + str(len(public)) + " public metadata record(s) to " + str(destination))
    print("Original evidence and private custody log were not exported. Review metadata before sharing.")


def parser():
    cli = argparse.ArgumentParser(description=__doc__)
    commands = cli.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init", help="Create a new, private case directory; parent must exist")
    init.add_argument("case_dir")
    add = commands.add_parser("add", help="Copy a regular file into private originals and record its SHA-256")
    add.add_argument("case_dir")
    add.add_argument("file")
    add.add_argument("--case", required=True, help="Stable case identifier")
    add.add_argument("--title", required=True)
    add.add_argument("--collector", required=True)
    add.add_argument("--source", required=True, help="Declared provenance: URL, issuing office, or source description")
    add.add_argument("--event-date", default="", help="Optional YYYY-MM-DD or ISO timestamp with timezone")
    add.add_argument("--access", choices=("public", "restricted"), default="restricted")
    verify = commands.add_parser("verify", help="Check file bytes, metadata, custody links, and orphan intake files")
    verify.add_argument("case_dir")
    export = commands.add_parser("export", help="Export public metadata only; never exports originals")
    export.add_argument("case_dir")
    export.add_argument("--output", required=True)
    return cli


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.command == "init":
            init_case(args.case_dir)
        elif args.command == "add":
            add_file(args)
        elif args.command == "verify":
            verify_case(args.case_dir)
        elif args.command == "export":
            export_case(args.case_dir, args.output)
        return 0
    except (EvidenceError, OSError) as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
