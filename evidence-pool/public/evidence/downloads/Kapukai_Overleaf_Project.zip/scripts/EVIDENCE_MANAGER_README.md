# Local evidence manager

**Use an encrypted, access-controlled local volume for private case folders and an encrypted backup. This program does not encrypt files. A SHA-256 hash shows byte consistency; it does not prove truth, authenticity, provenance, legal admissibility, or cause. Originals remain private. Upload only deliberately public or properly redacted derivatives to Overleaf.**

This standard-library Python 3.9+ utility copies evidence into a private case folder, records provenance declarations, and checks whether stored bytes and registered metadata still agree. It never moves or deletes your source files, fetches network content, or uploads evidence. Reading a source may update its filesystem access time; use qualified forensic acquisition when that matters.

## Start

Open a terminal in the folder containing `evidence_manager.py`. Replace the example paths and facts with your own. The parent folder must already exist; the new case folder must not exist.

```bash
python3 evidence_manager.py init /encrypted-volume/CASE-001
python3 evidence_manager.py add /encrypted-volume/CASE-001 /path/to/source.pdf --case CASE-001 --title "Public agency report" --collector "Your name or appropriate collector ID" --source "https://agency.example/report" --event-date 2026-10-01 --access restricted
python3 evidence_manager.py verify /encrypted-volume/CASE-001
python3 evidence_manager.py export /encrypted-volume/CASE-001 --output /path/to/new-public-export
```

On Windows, `py -3` can replace `python3`; quote paths containing spaces. Use an access-controlled filesystem that supports hard links and atomic replacement. If hard links are unavailable, intake fails rather than falling back to a non-atomic overwrite.

`--access` defaults to `restricted`. Only `public` records appear in an export. Public applies to **metadata visibility**: the tool never exports exhibit file contents. For a source suitable for sharing, add a separate, reviewed redacted derivative with `--access public`, describe the parent exhibit ID and redactions in `--source`, and give it its own exhibit ID. Do not edit an existing intake file to redact it. The tool does not itself perform or validate redaction.

`--event-date` is a declared event date, distinct from the intake timestamp. It accepts `YYYY-MM-DD` or an ISO timestamp with an explicit timezone, such as `2026-10-01T15:00:00-04:00`. An omitted event date stays blank. Do not invent dates or collectors.

## Private case layout

```text
CASE-001/
  manifest.json
  chain-of-custody.jsonl
  evidence/
    originals/       copied exhibit bytes, unique ID, original extension
    derivatives/     workspace for your separately documented redacted copies
```

The manifest records each exhibit's ID, case ID, title, collector, declared source, declared event date, access designation, original filename, relative intake path, SHA-256, byte count, and UTC intake timestamp. Original absolute source paths are not recorded automatically. The custody log records initialization and each intake, linked by event hashes and a hash of the complete manifest record.

Treat originals as immutable; derive new files instead. Intake files are set read-only as an application convention. This is **not** a forensic write blocker, WORM storage, signed timestamp service, or tamper-proof ledger. Filesystem owners or administrators can change bytes, metadata, or an entire log and recalculate hashes. External signed checkpoints or independently preserved copies are needed to detect a wholesale rewrite or rollback. The chain covers this tool's initialization and intake events, not every real-world transfer or every read. Document external custody changes separately.

## Export and Overleaf

Exports are refused if the output directory already exists or is inside the private case directory. A successful export contains:

- `exhibit-register.json`: exact public-designated metadata, except omitted local paths in the source field.
- `exhibit-register.csv`: the same register; values that could start spreadsheet formulas receive a leading apostrophe.
- `exhibit-catalog.tex`: a standalone, safely escaped catalog; compile it with **pdfLaTeX** in Overleaf. No shell escape is needed.
- `READ-BEFORE-SHARING.txt`: scope and review reminders.

Private metadata, originals, and the private custody log are excluded. Absolute local paths occupying the source field are replaced with an omission note. This is not automatic privacy review: inspect original filenames, titles, collector identities, URLs, embedded paths, and free text yourself. Public designations do not establish consent or lawful disclosure.

All TeX special characters are escaped. Non-ASCII characters are printed as `[U+XXXX]` tokens for predictable pdfLaTeX compilation, while JSON retains the exact Unicode text. Keep the JSON register when precise names matter. The catalog is metadata, not substantive proof, and should accompany correctly cited and reviewed exhibits.

If you want to include the catalog in another LaTeX document, use its contents between `\begin{document}` and `\end{document}` and make sure the parent loads `longtable` and `array`. Alternatively compile the catalog separately and include the resulting PDF. Do not upload the whole private case folder to a shared project.

## Integrity and interrupted work

`verify` checks hashes, sizes, record hashes, custody links, duplicate identifiers, unsafe paths, and unregistered files in `originals`. `add` and `export` first require the existing case to pass this check. A changed source file outside the case does not alter its earlier copied exhibit.

The program refuses symlink components and unsafe exhibit paths, uses exclusive locks and atomic file publication/replacement, and creates folders with private POSIX permissions. Windows permissions depend on the enclosing volume's ACLs. It is intended for a directory you control; path checks are not a defense against an administrator or a hostile process racing filesystem changes.

The exhibit copy, custody append, and manifest update are separate operations, not a database transaction. A crash can leave an unregistered copy, an incomplete export, or a log/manifest mismatch. `verify` detects these inconsistencies and refuses further intake/export. Preserve the entire folder and examine the discrepancy before repair; do not delete or edit evidence to make a check pass. An interrupted export may be incomplete; use a new output directory after resolving the cause. If a lock remains after a crash, first confirm that no manager process is running, then remove only `.evidence-manager.lock` manually.

There is no delete, replace, access-change, or in-place metadata-edit command. Record a correction in a new source note or derivative with a reference to the original exhibit, then add it as a new exhibit. An unintentional public designation should be treated as a privacy review problem before any export is shared; this utility does not publish anything automatically.

## Check the utility

```bash
python3 -m unittest -v test_evidence_manager.py
```

The tests create temporary folders and verify source preservation, byte and metadata tampering, custody tampering/truncation, path traversal refusal, symlink refusal, orphan detection, public-only export, no-overwrite behavior, private-path omission, hostile TeX text, spreadsheet formula protection, dates, and locks. They do not establish forensic accreditation or legal admissibility.
