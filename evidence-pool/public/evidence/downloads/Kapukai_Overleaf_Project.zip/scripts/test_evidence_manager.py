#!/usr/bin/env python3
"""Portable integration checks using temporary files and real CLI invocations."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).with_name("evidence_manager.py")
spec = importlib.util.spec_from_file_location("evidence_manager", SCRIPT)
manager = importlib.util.module_from_spec(spec)
spec.loader.exec_module(manager)


class EvidenceManagerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.case = self.root / "private-case"
        self.run_cli("init", self.case)

    def tearDown(self):
        for path in self.root.rglob("*"):
            if path.is_file() and not path.is_symlink():
                path.chmod(0o600)
        self.temp.cleanup()

    def run_cli(self, *args, ok=True):
        result = subprocess.run([sys.executable, str(SCRIPT), *map(str, args)], text=True, capture_output=True)
        if ok:
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        else:
            self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        return result

    def add(self, name="source.txt", access="restricted", title="Original evidence", source="Public report"):
        path = self.root / name
        path.write_bytes(b"Unchanged evidence bytes\n")
        self.run_cli("add", self.case, path, "--case", "CASE-001", "--title", title,
                     "--collector", "Example Collector", "--source", source,
                     "--event-date", "2026-10-01", "--access", access)
        return path

    def manifest(self):
        return json.loads((self.case / "manifest.json").read_text())

    def rewrite_manifest(self, value):
        (self.case / "manifest.json").write_text(json.dumps(value))

    def test_intake_and_hash_preserve_source(self):
        original = self.add(name="report.PDF")
        entry = self.manifest()["exhibits"][0]
        self.assertEqual(original.read_bytes(), b"Unchanged evidence bytes\n")
        stored = self.case / entry["relative_path"]
        self.assertEqual(stored.suffix, ".PDF")
        self.assertEqual(stored.read_bytes(), original.read_bytes())
        self.assertEqual(entry["sha256"], hashlib.sha256(original.read_bytes()).hexdigest())
        self.assertEqual(entry["byte_size"], len(original.read_bytes()))
        self.assertTrue(entry["acquired_utc"].endswith("Z"))
        self.assertNotIn(str(original), json.dumps(entry))
        self.run_cli("verify", self.case)
        original.write_bytes(b"Later source edit is separate")
        self.run_cli("verify", self.case)

    def test_tamper_blocks_verify_add_and_export(self):
        self.add()
        path = self.case / self.manifest()["exhibits"][0]["relative_path"]
        path.chmod(0o600)
        path.write_bytes(b"altered")
        result = self.run_cli("verify", self.case, ok=False)
        self.assertIn("Bytes changed", result.stderr)
        self.run_cli("export", self.case, "--output", self.root / "share", ok=False)
        other = self.root / "other.txt"
        other.write_text("new")
        self.run_cli("add", self.case, other, "--case", "CASE-001", "--title", "other",
                     "--collector", "A", "--source", "B", ok=False)

    def test_metadata_change_and_custody_tamper_detected(self):
        self.add()
        original_manifest = self.manifest()
        altered = json.loads(json.dumps(original_manifest))
        altered["exhibits"][0]["title"] = "Changed title"
        self.rewrite_manifest(altered)
        result = self.run_cli("verify", self.case, ok=False)
        self.assertIn("metadata differs", result.stderr)
        self.rewrite_manifest(original_manifest)
        log = self.case / "chain-of-custody.jsonl"
        lines = log.read_text().splitlines()
        event = json.loads(lines[1])
        event["details"]["case_id"] = "FORGED"
        lines[1] = json.dumps(event)
        log.write_text("\n".join(lines) + "\n")
        self.assertIn("Custody log integrity failure", self.run_cli("verify", self.case, ok=False).stderr)

    def test_manifest_paths_cannot_escape_originals(self):
        self.add()
        original = self.manifest()
        bad_paths = ["../secret.txt", "/etc/passwd", "evidence/originals/../../../etc/passwd",
                     "evidence/originals/../secret.txt", "evidence/originals//name.txt",
                     "evidence\\originals\\name.txt", "C:/Windows/secret.txt", "evidence/derivatives/name.txt"]
        for bad in bad_paths:
            altered = json.loads(json.dumps(original))
            altered["exhibits"][0]["relative_path"] = bad
            self.rewrite_manifest(altered)
            self.run_cli("verify", self.case, ok=False)
        self.rewrite_manifest(original)
        self.run_cli("verify", self.case)

    @unittest.skipIf(os.name == "nt", "Windows symlink creation may require administrator privileges")
    def test_symlinks_rejected(self):
        source = self.root / "real.txt"
        source.write_text("actual")
        link = self.root / "link.txt"
        link.symlink_to(source)
        self.assertIn("Symlinks are refused", self.run_cli("add", self.case, link, "--case", "A",
                      "--title", "A", "--collector", "A", "--source", "A", ok=False).stderr)
        case_link = self.root / "case-link"
        case_link.symlink_to(self.case, target_is_directory=True)
        self.run_cli("verify", case_link, ok=False)
        self.add()
        exhibit = self.case / self.manifest()["exhibits"][0]["relative_path"]
        exhibit.unlink()
        exhibit.symlink_to(source)
        self.run_cli("verify", self.case, ok=False)

    def test_export_public_metadata_only_and_never_overwrites(self):
        self.add(name="private.txt", title="PRIVATE SECRET")
        self.add(name="public.txt", access="public", title="Public", source=str(self.root / "private-location.txt"))
        output = self.root / "share"
        self.run_cli("export", self.case, "--output", output)
        register = json.loads((output / "exhibit-register.json").read_text())
        self.assertEqual(len(register["exhibits"]), 1)
        self.assertNotIn("relative_path", register["exhibits"][0])
        self.assertIn("omitted", register["exhibits"][0]["source"])
        for path in output.iterdir():
            text = path.read_text()
            self.assertNotIn("PRIVATE SECRET", text)
            self.assertNotIn(str(self.root), text)
            self.assertNotIn("Unchanged evidence bytes", text)
        self.assertEqual(len(list(output.iterdir())), 4)
        self.run_cli("export", self.case, "--output", output, ok=False)
        self.run_cli("export", self.case, "--output", self.case / "export", ok=False)

    def test_hostile_tex_and_csv_values_are_escaped(self):
        title = r"=1+1 % \input{secret} & $ # _ ~ ^" + " \u2603"
        filename = "evil%_{x}#.txt"
        self.add(name=filename, access="public", title=title)
        output = self.root / "export"
        self.run_cli("export", self.case, "--output", output)
        tex = (output / "exhibit-catalog.tex").read_text()
        self.assertNotIn(r"\input{secret}", tex)
        self.assertIn(r"\textbackslash{}input\{secret\}", tex)
        self.assertIn(r"evil\%\_\{x\}\#.txt", tex)
        self.assertIn("[U+2603]", tex)
        self.assertIn("'=1+1", (output / "exhibit-register.csv").read_text())
        register = json.loads((output / "exhibit-register.json").read_text())
        self.assertEqual(register["exhibits"][0]["title"], title)

    def test_orphan_and_truncated_log_are_detected(self):
        self.add()
        orphan = self.case / "evidence" / "originals" / "unregistered.txt"
        orphan.write_text("orphan")
        self.assertIn("Unregistered", self.run_cli("verify", self.case, ok=False).stderr)
        orphan.unlink()
        log = self.case / "chain-of-custody.jsonl"
        log.write_text(log.read_text().splitlines()[0] + "\n")
        self.assertIn("exhibit sets differ", self.run_cli("verify", self.case, ok=False).stderr)

    def test_empty_export_and_existing_init_refused(self):
        self.run_cli("init", self.case, ok=False)
        self.run_cli("verify", self.case)
        output = self.root / "empty-export"
        self.run_cli("export", self.case, "--output", output)
        self.assertEqual(json.loads((output / "exhibit-register.json").read_text())["exhibits"], [])

    def test_invalid_event_date_and_lock(self):
        source = self.root / "source.txt"
        source.write_text("test")
        self.run_cli("add", self.case, source, "--case", "A", "--title", "A", "--collector", "A",
                     "--source", "A", "--event-date", "2026-02-31", ok=False)
        (self.case / ".evidence-manager.lock").write_text("test")
        self.assertIn("Case is locked", self.run_cli("verify", self.case, ok=False).stderr)

    @unittest.skipUnless(shutil.which("pdflatex"), "Optional pdfLaTeX executable is not installed")
    def test_generated_catalog_compiles_with_hostile_text(self):
        self.add(name="proof%_{x}#.pdf", access="public",
                 title=r"Untrusted \input{missing} \write18{touch should-not-exist} # & % $ _ ^ ~" + " \u2603")
        output = self.root / "tex-export"
        self.run_cli("export", self.case, "--output", output)
        result = subprocess.run([shutil.which("pdflatex"), "-no-shell-escape", "-halt-on-error",
                                 "-interaction=nonstopmode", "exhibit-catalog.tex"],
                                cwd=output, text=True, capture_output=True, timeout=60)
        self.assertEqual(result.returncode, 0, result.stdout[-3000:] + result.stderr)
        self.assertTrue((output / "exhibit-catalog.pdf").is_file())
        self.assertFalse((output / "should-not-exist").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
