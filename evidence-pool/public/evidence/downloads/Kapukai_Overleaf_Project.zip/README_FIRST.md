# Kapukai evidence dossier and atlas - v1.0

Research cutoff: 2026-10-01. This is a bounded public-source research edition, not proof of a single network or of anyone's personal targeting.

## Read
- `compiled/main.pdf`: case dossier, timelines, claim reviews, controls and source register.
- `compiled/atlas.pdf`: connection maps with typed edges and limitations.
- `compiled/toolkit.pdf`: reusable blank research and evidence forms.

## Overleaf
1. Download the Overleaf ZIP and choose **New Project > Upload Project**.
2. Select **pdfLaTeX** and choose `main.tex` as the main document.
3. Recompile. Choose `atlas.tex` or `toolkit.tex` as the main document to compile each companion.
4. All diagrams are native LaTeX/TikZ. No shell escape, paid package, external API or BibTeX run is required.

For local builds, install a normal TeX Live distribution with latexmk and run `bash scripts/build_all.sh` from the project. PDFs are written to `compiled/`. On Overleaf, each selected main document generates its own downloadable PDF. Overleaf does not run the Python evidence manager.

## Edit and extend
Edit the generated `.tex` files directly, or edit the five `data/research_*.json` input files and run `python3 scripts/build_dossier.py`, then `python3 scripts/build_atlas.py`, then `bash scripts/build_all.sh`. The combined `data/research.json` and CSVs are generated outputs. Do not mix direct edits and regeneration without a backup. Each claim needs a source ID, pinpoint and status; each relationship needs a typed edge. `sources.bib` is supplied for reuse, while this edition uses an in-document source register. The CSV registers can be opened in a spreadsheet.

## Evidence storage
The Overleaf ZIP contains public research and forms only. The full research-system ZIP additionally contains selected public government source PDFs, provenance records and the local evidence manager. Citation-only sources are not claimed to be collected originals. A downloaded PDF is not a certified custodian copy.

For your own case use a separate local folder with `scripts/evidence_manager.py`; read its README before use. The tool copies input files; it does not move or delete them. Restricted originals must remain out of public GitHub and ordinary Overleaf projects. Do not add classified, sealed or otherwise restricted material to this public project. No passwords, identity documents, medical files or private allegations were included in this edition.

## Public transparency pool
The public website edition is prepared separately. Public-source submissions should be reviewed before publication. Maintain a correction log and update all affected timelines and maps. This packet makes no claim that a website or GitHub repository has been deployed.

## Verification and scope
Read `qa/BUILD_REPORT.md` for actual compilation and checks. There are 21 case/context modules, 71 source records and 20 defensive control domains in the data. Scope includes some secondary reports and mirrored primary records; read source-specific limits. Source URLs can change. No agency contacts or records requests have been sent.

Original Kapukai-authored templates and software are provided for reuse and adaptation. Third-party source documents retain their own legal status; no blanket license is granted for them. Preserve attribution and clearly mark changes.
